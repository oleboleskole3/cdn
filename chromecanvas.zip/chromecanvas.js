const { spawn } = require('child_process');
const http = require('http');

chrome = spawn('chromed')

//chrome.stdout.pipe(process.stdout);

port = null
sessionId = null
onStart = []

fill = true
stroke = true

chrome.stdout.on('data', async (data) => {
	portMatch = data.toString().match(/((?<=port )\d+)/)
	if (portMatch) {
		port = portMatch[0]
		console.log(port)
		return
	}
	
	sessionId = (await sendData('POST', '/session', {
		capabilities: {}
	})).data.value.sessionId

	await sendData('POST', `/session/${sessionId}/url`, {
		url: 'data:text/html;base64,PGJvZHkgc3R5bGU9Im1hcmdpbjowOyI+DQo8Y2FudmFzIHdpZHRoPTIwMCBoZWlnaHQ9MjAwPjwvY2FudmFzPg0KPHNjcmlwdD4NCmNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2NhbnZhcycpOw0KY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7DQo8L3NjcmlwdD4NCjwvYm9keT4='
	});

	onStart.forEach(callback => callback())
	onStart = null
});

async function execute_script(js) {
	await sendData('POST', `/session/${sessionId}/execute/sync`, {
		script: js,
		args: []
	});
}

function sendData(method, path, body) {
	body = JSON.stringify(body);
	return new Promise((resolve, reject) => {
		const options = {
			hostname: 'localhost',
			port: port,
			path: path,
			method: method,
			headers: {
				'Content-Type': 'application/json',
				'Content-Length': body.length
			}
		}

		const req = http.request(options, res => {
			//console.log('Status code: ' + res.statusCode)
			
			response = ''

			res.on('data', data => {
				response += data.toString();
			})
			res.on('end', () => {
				resolve({data: JSON.parse(response), resObj: res})
			})
		});

		req.write(body);
		req.end();
	})
}

exports.onStart = () => {
	return new Promise(resolve => {
		if (onStart === null)
			resolve()
		else
			onStart.push(resolve)
	})
}

exports.line = async (x1, y1, x2, y2) => {
	if (stroke)
		await execute_script(`ctx.beginPath();ctx.moveTo(${x1}, ${y1});ctx.lineTo(${x2}, ${y2});ctx.stroke();`);
}

/*exports.triangle = async (x1, y1, x2, y2, x3, y3) => {
	code = ''
	if (fill)
		code += `new Path2D('').fill()`
	if (stroke)
		code += `ctx.strokeRect(${x},${y},${w},${h});`
	await execute_script(code);
}*/

exports.setSize = async (w, h) => {
	await execute_script(`canvas.width = ${w}; canvas.height = ${h}`);
}

exports.rect = async (x, y, w, h) => {
	code = ''
	if (fill)
		code += `ctx.fillRect(${x},${y},${w},${h});`
	if (stroke)
		code += `ctx.strokeRect(${x},${y},${w},${h});`
	await execute_script(code);
}

exports.fill = async (v1, v2, v3) => {
	fill = true
	await execute_script(`ctx.fillStyle = 'rgb(${v1},${v2},${v3})';`)
}

exports.stroke = async (v1, v2, v3) => {
	stroke = true
	await execute_script(`ctx.strokeStyle = 'rgb(${v1},${v2},${v3})';`)
}

exports.clearFill = () => {
	fill = false
}

exports.clearStroke = () => {
	stroke = false
}

exports.strokeSize = async px => {
	await execute_script(`ctx.lineWidth = ${px}`);
}